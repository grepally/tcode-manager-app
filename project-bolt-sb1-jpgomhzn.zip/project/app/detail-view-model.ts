import { Observable, Page } from '@nativescript/core';
import { TCode } from './shared/t-code.model';

export class DetailViewModel extends Observable {
    private _tcode: TCode;
    private _page: Page;

    constructor(tcode: TCode, page: Page) {
        super();
        this._tcode = tcode;
        this._page = page;
    }

    get tcode(): TCode {
        return this._tcode;
    }

    onBack() {
        this._page.frame.goBack();
    }

    onEdit() {
        // Reuse the edit functionality from main view model
        const mainVM = this._page.frame.page.bindingContext;
        mainVM.editTCode(this._tcode);
    }
}
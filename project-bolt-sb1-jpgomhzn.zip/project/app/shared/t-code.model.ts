export interface TCode {
    id: string;
    code: string;
    description: string;
    createdAt: Date;
}
import { Observable } from '@nativescript/core';
import { TCode } from './t-code.model';
import { getString, setString } from '@nativescript/core/application-settings';

export class TCodeService extends Observable {
    private tcodes: TCode[] = [];
    private STORAGE_KEY = 'tcodes';

    constructor() {
        super();
        this.loadTCodes();
    }

    private loadTCodes() {
        const savedData = getString(this.STORAGE_KEY);
        if (savedData) {
            this.tcodes = JSON.parse(savedData);
        }
    }

    private saveTCodes() {
        setString(this.STORAGE_KEY, JSON.stringify(this.tcodes));
    }

    getAllTCodes(): TCode[] {
        return [...this.tcodes];
    }

    searchTCodes(query: string): TCode[] {
        query = query.toLowerCase();
        return this.tcodes.filter(tcode => 
            tcode.code.toLowerCase().includes(query) ||
            tcode.description.toLowerCase().includes(query)
        );
    }

    addTCode(code: string, description: string): void {
        const newTCode: TCode = {
            id: Date.now().toString(),
            code,
            description,
            createdAt: new Date()
        };
        this.tcodes.push(newTCode);
        this.saveTCodes();
    }

    updateTCode(id: string, code: string, description: string): void {
        const index = this.tcodes.findIndex(t => t.id === id);
        if (index !== -1) {
            this.tcodes[index] = {
                ...this.tcodes[index],
                code,
                description
            };
            this.saveTCodes();
        }
    }

    deleteTCode(id: string): void {
        this.tcodes = this.tcodes.filter(t => t.id !== id);
        this.saveTCodes();
    }
}
import { Observable } from '@nativescript/core';
import { TCodeService } from './shared/t-code.service';
import { TCode } from './shared/t-code.model';
import { prompt, action, alert } from '@nativescript/core/ui/dialogs';
import { Frame } from '@nativescript/core';

export class MainViewModel extends Observable {
    private tCodeService: TCodeService;
    private _searchQuery: string = '';
    private _filteredTCodes: TCode[] = [];

    constructor() {
        super();
        this.tCodeService = new TCodeService();
        this.refreshTCodes();
    }

    get filteredTCodes(): TCode[] {
        return this._filteredTCodes;
    }

    get searchQuery(): string {
        return this._searchQuery;
    }

    set searchQuery(value: string) {
        if (this._searchQuery !== value) {
            this._searchQuery = value;
            this.notifyPropertyChange('searchQuery', value);
            this.filterTCodes();
        }
    }

    onSearchTextChanged(args: any) {
        this.searchQuery = args.object.text;
    }

    private filterTCodes() {
        this._filteredTCodes = this.searchQuery 
            ? this.tCodeService.searchTCodes(this.searchQuery)
            : this.tCodeService.getAllTCodes();
        this.notifyPropertyChange('filteredTCodes', this._filteredTCodes);
    }

    async onNew() {
        const options = {
            title: "New T-Code",
            message: "Enter T-Code and Description",
            okButtonText: "Save",
            cancelButtonText: "Cancel",
            neutralButtonText: "Clear",
            defaultText: "",
            inputType: "text",
        };

        try {
            const codePrompt = await prompt({
                ...options,
                message: "Enter T-Code",
                textFieldHint: "T-Code"
            });

            if (codePrompt.result) {
                const descPrompt = await prompt({
                    ...options,
                    message: "Enter Description",
                    textFieldHint: "Description"
                });

                if (descPrompt.result) {
                    this.tCodeService.addTCode(codePrompt.text, descPrompt.text);
                    this.refreshTCodes();
                }
            }
        } catch (error) {
            console.error('Error adding T-Code:', error);
        }
    }

    async onTCodeLongPress(args: any) {
        const tcode = args.view.bindingContext;
        const result = await action({
            title: `T-Code: ${tcode.code}`,
            message: "Choose an action",
            cancelButtonText: "Cancel",
            actions: ["Edit", "Delete"]
        });

        if (result === "Edit") {
            await this.editTCode(tcode);
        } else if (result === "Delete") {
            await this.deleteTCode(tcode);
        }
    }

    private async editTCode(tcode: TCode) {
        const codePrompt = await prompt({
            title: "Edit T-Code",
            message: "Update T-Code",
            okButtonText: "Next",
            cancelButtonText: "Cancel",
            defaultText: tcode.code,
        });

        if (codePrompt.result) {
            const descPrompt = await prompt({
                title: "Edit Description",
                message: "Update Description",
                okButtonText: "Save",
                cancelButtonText: "Cancel",
                defaultText: tcode.description,
            });

            if (descPrompt.result) {
                this.tCodeService.updateTCode(tcode.id, codePrompt.text, descPrompt.text);
                this.refreshTCodes();
            }
        }
    }

    private async deleteTCode(tcode: TCode) {
        const confirmResult = await confirm({
            title: "Delete T-Code",
            message: `Are you sure you want to delete ${tcode.code}?`,
            okButtonText: "Delete",
            cancelButtonText: "Cancel"
        });

        if (confirmResult) {
            this.tCodeService.deleteTCode(tcode.id);
            this.refreshTCodes();
        }
    }

    onTCodeTap(args: any) {
        const tcode = args.view.bindingContext;
        alert({
            title: tcode.code,
            message: tcode.description,
            okButtonText: "OK"
        });
    }

    private refreshTCodes() {
        this._filteredTCodes = this.tCodeService.getAllTCodes();
        this.notifyPropertyChange('filteredTCodes', this._filteredTCodes);
    }
}
import { EventData, Page, NavigatedData } from '@nativescript/core';
import { DetailViewModel } from './detail-view-model';

export function onNavigatingTo(args: NavigatedData) {
    const page = <Page>args.object;
    const tcode = args.context;
    page.bindingContext = new DetailViewModel(tcode, page);
}